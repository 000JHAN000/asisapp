import { Module, forwardRef } from '@nestjs/common';
import { TypeOrmModule }      from '@nestjs/typeorm';
import { AsistenciaOrmEntity }         from './infrastructure/entities/asistencia.orm-entity';
import { AsistenciaTypeOrmRepository } from './infrastructure/adapters/asistencia.typeorm.repository';
import { AsistenciaService }           from './application/asistencia.service';
import { AsistenciaController }        from './infrastructure/http/asistencia.controller';
import { ASISTENCIA_REPOSITORY }       from './domain/ports/asistencia.repository.port';
import { QueuesModule }                from 'src/queues/queues.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([AsistenciaOrmEntity]),
    forwardRef(() => QueuesModule), 
  ],
  controllers: [AsistenciaController],
  providers: [
    AsistenciaService,
    {
      provide: ASISTENCIA_REPOSITORY,
      useClass: AsistenciaTypeOrmRepository,
    },
  ],
  exports: [AsistenciaService],
})
export class AsistenciaModule {}