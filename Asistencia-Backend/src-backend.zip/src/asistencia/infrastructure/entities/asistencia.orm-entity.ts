import { Column, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { EstadoAprendiz } from '../../domain/entities/asistencia.entity';
import { FormacionOrmEntity } from 'src/formacion/infrastructure/entities/formacion.orm-entity';

@Entity()
export class AsistenciaOrmEntity {
  @PrimaryGeneratedColumn('uuid')
  id_asistencia: string;

  @Column({ type: 'enum', enum: EstadoAprendiz })
  estado_aprendiz: EstadoAprendiz;

  @Column({ type: 'time' })
  hora: string;

  @Column({ type: 'varchar', length: 260, nullable: true })
  observaciones: string;

  @Column('uuid')
  formacion_fk: string;

  @ManyToOne(() => FormacionOrmEntity, (formacion) => formacion.asistencias)
  @JoinColumn({ name: 'formacion_fk' })
  formacion: FormacionOrmEntity;
}