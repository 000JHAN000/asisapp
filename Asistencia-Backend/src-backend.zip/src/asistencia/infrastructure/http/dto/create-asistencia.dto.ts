import { IsEnum, IsOptional, IsString, IsUUID } from 'class-validator';
import { EstadoAprendiz } from '../../../domain/entities/asistencia.entity';

export class CreateAsistenciaDto {
  @IsEnum(EstadoAprendiz)
  estado_aprendiz: EstadoAprendiz;

  @IsString()
  hora: string;

  @IsOptional()
  @IsString()
  observaciones: string;

  @IsUUID()
  formacion_fk: string;
}