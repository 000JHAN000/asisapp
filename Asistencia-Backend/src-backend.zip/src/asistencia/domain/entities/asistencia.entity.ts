export enum EstadoAprendiz {
  asistio  = 'asistió',
  falla    = 'falla',
  tarde    = 'tarde',
  excusa   = 'excusa',
}

export class Asistencia {
  id_asistencia:  string;
  estado_aprendiz: EstadoAprendiz;
  hora:           string;
  observaciones:  string;
  formacion_fk:   string;
}