export enum DiaSemana {
  lunes     = 'LUNES',
  martes    = 'MARTES',
  miercoles = 'MIERCOLES',
  jueves    = 'JUEVES',
  viernes   = 'VIERNES',
  sabado    = 'SABADO',
}

export class Horario {
  id_horario:     string;
  dia_semana:     DiaSemana;
  hora_inicio:    string;
  hora_fin:       string;
  curso_fk:       string;
  instructor_fk:  string;
  ambiente_fk:    string;
}