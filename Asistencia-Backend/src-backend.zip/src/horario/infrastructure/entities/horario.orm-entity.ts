import { Column, Entity, JoinColumn, ManyToOne, OneToMany, PrimaryGeneratedColumn } from 'typeorm';
import { DiaSemana } from '../../domain/entities/horario.entity';
import { CursoOrmEntity }      from 'src/curso/infrastructure/entities/curso.orm-entity';
import { PersonaOrmEntity }    from 'src/persona/infrastructure/entities/persona.orm-entity';
import { AmbienteOrmEntity }   from 'src/ambiente/infrastructure/entities/ambiente.orm-entity';
import { FormacionOrmEntity }  from 'src/formacion/infrastructure/entities/formacion.orm-entity';

@Entity()
export class HorarioOrmEntity {
  @PrimaryGeneratedColumn('uuid')
  id_horario: string;

  @Column({ type: 'enum', enum: DiaSemana })
  dia_semana: DiaSemana;

  @Column({ type: 'time' })
  hora_inicio: string;

  @Column({ type: 'time' })
  hora_fin: string;

  @Column('uuid')
  curso_fk: string;

  @Column('uuid')
  instructor_fk: string;

  @Column('uuid')
  ambiente_fk: string;

  @ManyToOne(() => CursoOrmEntity)
  @JoinColumn({ name: 'curso_fk' })
  curso: CursoOrmEntity;

  @ManyToOne(() => PersonaOrmEntity)
  @JoinColumn({ name: 'instructor_fk' })
  instructor: PersonaOrmEntity;

  @ManyToOne(() => AmbienteOrmEntity)
  @JoinColumn({ name: 'ambiente_fk' })
  ambiente: AmbienteOrmEntity;

  @OneToMany(() => FormacionOrmEntity, (formacion) => formacion.horario)
  formaciones: FormacionOrmEntity[];
}