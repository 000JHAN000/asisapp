import { IsEnum, IsString, IsUUID } from 'class-validator';
import { DiaSemana } from '../../../domain/entities/horario.entity';

export class CreateHorarioDto {
  @IsEnum(DiaSemana)
  dia_semana: DiaSemana;

  @IsString()
  hora_inicio: string;

  @IsString()
  hora_fin: string;

  @IsUUID()
  curso_fk: string;

  @IsUUID()
  instructor_fk: string;

  @IsUUID()
  ambiente_fk: string;
}