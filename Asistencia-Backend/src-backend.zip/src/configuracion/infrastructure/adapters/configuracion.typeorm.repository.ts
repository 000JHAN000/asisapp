import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { ConfiguracionRepositoryPort } from '../../domain/ports/configuracion.repository.port';
import { Configuracion } from '../../domain/entities/configuracion.entity';
import { ConfiguracionOrmEntity } from '../entities/configuracion.orm-entity';

@Injectable()
export class ConfiguracionTypeOrmRepository implements ConfiguracionRepositoryPort {

  constructor(
    @InjectRepository(ConfiguracionOrmEntity)
    private readonly repo: Repository<ConfiguracionOrmEntity>,
  ) {}

  crear(datos: Partial<Configuracion>): Promise<Configuracion> {
    const nuevo = this.repo.create(datos);
    return this.repo.save(nuevo);
  }

  listar(): Promise<Configuracion[]> {
    return this.repo.find({ relations: ['matricula'] });
  }

  async buscarPorId(id: string): Promise<Configuracion> {
    const encontrado = await this.repo.findOne({
      where: { id_configuracion: id },
      relations: ['matricula'],
    });
    if (!encontrado) throw new NotFoundException(`Configuracion ${id} no existe`);
    return encontrado;
  }

  async actualizar(id: string, datos: Partial<Configuracion>): Promise<void> {
    await this.buscarPorId(id);
    await this.repo.update(id, datos);
  }

  async eliminar(id: string): Promise<void> {
    await this.buscarPorId(id);
    await this.repo.delete(id);
  }
}