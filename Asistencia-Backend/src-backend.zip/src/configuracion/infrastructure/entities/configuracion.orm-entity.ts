import { Column, Entity, JoinColumn, ManyToOne, OneToMany, PrimaryGeneratedColumn } from 'typeorm';
import { MatriculaOrmEntity } from 'src/matricula/infrastructure/entities/matricula.orm-entity';
import { FormacionOrmEntity } from 'src/formacion/infrastructure/entities/formacion.orm-entity';

@Entity()
export class ConfiguracionOrmEntity {
  @PrimaryGeneratedColumn('uuid')
  id_configuracion: string;

  @Column({ type: 'varchar', length: 260, nullable: true })
  firma: string;

  @Column({ type: 'varchar', length: 260, nullable: true })
  foto: string;

  @Column('uuid')
  matricula_fk: string;

  @ManyToOne(() => MatriculaOrmEntity)
  @JoinColumn({ name: 'matricula_fk' })
  matricula: MatriculaOrmEntity;

  @OneToMany(() => FormacionOrmEntity, (formacion) => formacion.configuracion)
  formaciones: FormacionOrmEntity[];
}