import { IsOptional, IsString, IsUUID, MaxLength } from 'class-validator';

export class CreateConfiguracionDto {
  @IsOptional()
  @IsString()
  @MaxLength(260)
  firma: string;

  @IsOptional()
  @IsString()
  @MaxLength(260)
  foto: string;

  @IsUUID()
  matricula_fk: string;
}