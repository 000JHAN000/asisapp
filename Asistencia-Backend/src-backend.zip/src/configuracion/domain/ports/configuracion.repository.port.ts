import { Configuracion } from '../entities/configuracion.entity';

export const CONFIGURACION_REPOSITORY = 'CONFIGURACION_REPOSITORY';

export interface ConfiguracionRepositoryPort {
  crear(datos: Partial<Configuracion>): Promise<Configuracion>;
  listar(): Promise<Configuracion[]>;
  buscarPorId(id: string): Promise<Configuracion | null>;
  actualizar(id: string, datos: Partial<Configuracion>): Promise<void>;
  eliminar(id: string): Promise<void>;
}