export class Configuracion {
  id_configuracion: string;
  firma:            string;
  foto:             string;
  matricula_fk:     string;
}