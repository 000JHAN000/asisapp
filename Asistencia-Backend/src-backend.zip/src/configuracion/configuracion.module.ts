import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ConfiguracionOrmEntity }         from './infrastructure/entities/configuracion.orm-entity';
import { ConfiguracionTypeOrmRepository } from './infrastructure/adapters/configuracion.typeorm.repository';
import { ConfiguracionService }           from './application/configuracion.service';
import { ConfiguracionController }        from './infrastructure/http/configuracion.controller';
import { CONFIGURACION_REPOSITORY }       from './domain/ports/configuracion.repository.port';

@Module({
  imports: [TypeOrmModule.forFeature([ConfiguracionOrmEntity])],
  controllers: [ConfiguracionController],
  providers: [
    ConfiguracionService,
    {
      provide: CONFIGURACION_REPOSITORY,
      useClass: ConfiguracionTypeOrmRepository,
    },
  ],
})
export class ConfiguracionModule {}