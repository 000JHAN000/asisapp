import { Inject, Injectable } from '@nestjs/common';
import { type ConfiguracionRepositoryPort, CONFIGURACION_REPOSITORY } from '../domain/ports/configuracion.repository.port';
import { CreateConfiguracionDto } from '../infrastructure/http/dto/create-configuracion.dto';
import { UpdateConfiguracionDto } from '../infrastructure/http/dto/update-configuracion.dto';

@Injectable()
export class ConfiguracionService {

  constructor(
    @Inject(CONFIGURACION_REPOSITORY)
    private readonly repo: ConfiguracionRepositoryPort,
  ) {}

  create(dto: CreateConfiguracionDto) {
    return this.repo.crear(dto);
  }

  findAll() {
    return this.repo.listar();
  }

  findOne(id: string) {
    return this.repo.buscarPorId(id);
  }

  update(id: string, dto: UpdateConfiguracionDto) {
    return this.repo.actualizar(id, dto);
  }

  remove(id: string) {
    return this.repo.eliminar(id);
  }
}