import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { FormacionRepositoryPort } from '../../domain/ports/formacion.repository.port';
import { Formacion } from '../../domain/entities/formacion.entity';
import { FormacionOrmEntity } from '../entities/formacion.orm-entity';

@Injectable()
export class FormacionTypeOrmRepository implements FormacionRepositoryPort {

  constructor(
    @InjectRepository(FormacionOrmEntity)
    private readonly repo: Repository<FormacionOrmEntity>,
  ) {}

  crear(datos: Partial<Formacion>): Promise<Formacion> {
    const nuevo = this.repo.create(datos);
    return this.repo.save(nuevo);
  }

  listar(): Promise<Formacion[]> {
    return this.repo.find({ relations: ['horario', 'configuracion'] });
  }

  async buscarPorId(id: string): Promise<Formacion> {
    const encontrado = await this.repo.findOne({
      where: { id_formacion: id },
      relations: ['horario', 'configuracion'],
    });
    if (!encontrado) throw new NotFoundException(`Formacion ${id} no existe`);
    return encontrado;
  }

  async actualizar(id: string, datos: Partial<Formacion>): Promise<void> {
    await this.buscarPorId(id);
    await this.repo.update(id, datos);
  }

  async eliminar(id: string): Promise<void> {
    await this.buscarPorId(id);
    await this.repo.delete(id);
  }
}