import { IsDateString, IsEnum, IsOptional, IsString, IsUUID } from 'class-validator';
import { EstadoSesion } from '../../../domain/entities/formacion.entity';

export class CreateFormacionDto {
  @IsDateString()
  fecha: Date;

  @IsString()
  hora_inicio: string;

  @IsString()
  hora_fin: string;

  @IsUUID()
  horario_fk: string;

  @IsUUID()
  configuracion_fk: string;

  @IsOptional()
  @IsEnum(EstadoSesion)
  estado_sesion: EstadoSesion;
}