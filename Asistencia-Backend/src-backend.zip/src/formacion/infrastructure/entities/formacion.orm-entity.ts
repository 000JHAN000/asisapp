import { Column, Entity, JoinColumn, ManyToOne, OneToMany, PrimaryGeneratedColumn } from 'typeorm';
import { EstadoSesion } from '../../domain/entities/formacion.entity';
import { HorarioOrmEntity }       from 'src/horario/infrastructure/entities/horario.orm-entity';
import { ConfiguracionOrmEntity } from 'src/configuracion/infrastructure/entities/configuracion.orm-entity';
import { AsistenciaOrmEntity }    from 'src/asistencia/infrastructure/entities/asistencia.orm-entity';

@Entity()
export class FormacionOrmEntity {
  @PrimaryGeneratedColumn('uuid')
  id_formacion: string;

  @Column({ type: 'date' })
  fecha: Date;

  @Column({ type: 'time' })
  hora_inicio: string;

  @Column({ type: 'time' })
  hora_fin: string;

  @Column('uuid')
  horario_fk: string;

  @Column('uuid')
  configuracion_fk: string;

  @Column({
    type: 'enum',
    enum: EstadoSesion,
    default: EstadoSesion.abierta,
  })
  estado_sesion: EstadoSesion;

  @ManyToOne(() => HorarioOrmEntity, (horario) => horario.formaciones)
  @JoinColumn({ name: 'horario_fk' })
  horario: HorarioOrmEntity;

  @ManyToOne(() => ConfiguracionOrmEntity, (configuracion) => configuracion.formaciones)
  @JoinColumn({ name: 'configuracion_fk' })
  configuracion: ConfiguracionOrmEntity;

  @OneToMany(() => AsistenciaOrmEntity, (asistencia) => asistencia.formacion)
  asistencias: AsistenciaOrmEntity[];
}