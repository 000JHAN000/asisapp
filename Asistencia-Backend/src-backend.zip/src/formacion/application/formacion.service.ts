import { Inject, Injectable } from '@nestjs/common';
import { type FormacionRepositoryPort, FORMACION_REPOSITORY } from '../domain/ports/formacion.repository.port';
import { CreateFormacionDto } from '../infrastructure/http/dto/create-formacion.dto';
import { UpdateFormacionDto } from '../infrastructure/http/dto/update-formacion.dto';

@Injectable()
export class FormacionService {

  constructor(
    @Inject(FORMACION_REPOSITORY)
    private readonly repo: FormacionRepositoryPort,
  ) {}

  create(dto: CreateFormacionDto) {
    return this.repo.crear(dto);
  }

  findAll() {
    return this.repo.listar();
  }

  findOne(id: string) {
    return this.repo.buscarPorId(id);
  }

  update(id: string, dto: UpdateFormacionDto) {
    return this.repo.actualizar(id, dto);
  }

  remove(id: string) {
    return this.repo.eliminar(id);
  }
}