import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FormacionOrmEntity }         from './infrastructure/entities/formacion.orm-entity';
import { FormacionTypeOrmRepository } from './infrastructure/adapters/formacion.typeorm.repository';
import { FormacionService }           from './application/formacion.service';
import { FormacionController }        from './infrastructure/http/formacion.controller';
import { FORMACION_REPOSITORY }       from './domain/ports/formacion.repository.port';


@Module({
  imports: [TypeOrmModule.forFeature([FormacionOrmEntity])],
  controllers: [FormacionController],
  providers: [
    FormacionService,
    {
      provide: FORMACION_REPOSITORY,
      useClass: FormacionTypeOrmRepository,
    },
  ],
})
export class FormacionModule {}