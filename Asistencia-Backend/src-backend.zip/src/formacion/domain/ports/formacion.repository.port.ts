import { Formacion } from '../entities/formacion.entity';

export const FORMACION_REPOSITORY = 'FORMACION_REPOSITORY';

export interface FormacionRepositoryPort {
  crear(datos: Partial<Formacion>): Promise<Formacion>;
  listar(): Promise<Formacion[]>;
  buscarPorId(id: string): Promise<Formacion | null>;
  actualizar(id: string, datos: Partial<Formacion>): Promise<void>;
  eliminar(id: string): Promise<void>;
}