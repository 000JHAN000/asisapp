export enum EstadoSesion {
  abierta = 'ABIERTA',
  cerrada = 'CERRADA',
}

export class Formacion {
  id_formacion:     string;
  fecha:            Date;
  hora_inicio:      string;
  hora_fin:         string;
  horario_fk:       string;
  configuracion_fk: string;
  estado_sesion:    EstadoSesion;
}